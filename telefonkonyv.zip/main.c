#ifdef _WIN32
    #include <windows.h>
#endif

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>

#include "debugmalloc.h"
#include "struktura.h"
#include "menuk.h"
#include "fuggvenyek.h"

Rekord *lefoglaltelefonkonyv(Rekord *eleje){
    eleje = (Rekord*) malloc(sizeof(Rekord));
    eleje->kov = NULL;
    eleje->index = -2;
    return eleje;
}

int main(){
    #ifdef _WIN32
        SetConsoleCP(65001);
        SetConsoleOutputCP(65001);
    #endif
    Meretek maxmeret = {51, 21, 101, 51, 0};
    Rekord *telefonkonyv = NULL;
    telefonkonyv = lefoglaltelefonkonyv(telefonkonyv);
    bool vege = false;
    while(!vege){
        fomenu(&maxmeret, telefonkonyv, &vege);
    }
    felszabadit(telefonkonyv);
    return 0;
}
