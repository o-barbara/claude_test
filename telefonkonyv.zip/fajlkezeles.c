#ifdef _WIN32
    #include <windows.h>
#endif

#include <stdio.h>
#include <stdbool.h>
#include <string.h>
#include <math.h>

#include "debugmalloc.h"
#include "fuggvenyek.h"
#include "menuk.h"
#include "struktura.h"

void fajl_ut_beolvas(char*, char*);
Rekord *teljesrekord_lefoglal(int, Meretek);
bool mezo_beolvas(char*, char*, int, int*, char);
void rekordba_beolvas(Rekord*, char*, int*, Meretek);
int vcardolvasas_formatumellenorzes(FILE*);

void fajl_ut_beolvas(char *ut, char *tipus){
    fgets(ut, 200, stdin);
    char tipus_masolat[6];
    strcpy(tipus_masolat, tipus);
    *strchr(tipus_masolat, '\n') = '\0';
    bool jo_bemenet=false;
    while(!jo_bemenet){
        jo_bemenet = true;
        if(strchr(ut, '\n')==NULL){
            printf("A bemenet túl hosszú! Írd be újra!\n");
            char szemet;
            while(scanf("%c", &szemet)==1 && szemet!='\n');
            fgets(ut, 200, stdin);
            jo_bemenet = false;
        }
        else if(strstr(ut, tipus)==NULL){
            printf("Hibás fájlformátum! %s fájlt adj meg!\n", tipus_masolat);
            fgets(ut, 200, stdin);
            jo_bemenet = false;
        }
    }
    *strchr(ut, '\n') = '\0';
}

Rekord *teljesrekord_lefoglal(int index, Meretek maxmeret){
    bool sikertelen_lefoglalas = false;
    Rekord *uj = (Rekord*) malloc(sizeof(Rekord));
    if(uj==NULL) sikertelen_lefoglalas = true;
    uj->nev =(char*) malloc(maxmeret.n*sizeof(char));
    if(uj->nev==NULL) sikertelen_lefoglalas = true;
    uj->telefonszam =(char*) malloc(maxmeret.t*sizeof(char));
    if(uj->telefonszam==NULL) sikertelen_lefoglalas = true;
    uj->cim =(char*) malloc(maxmeret.c*sizeof(char));
    if(uj->cim==NULL) sikertelen_lefoglalas = true;
    uj->foglalkozas =(char*) malloc(maxmeret.f*sizeof(char));
    if(uj->foglalkozas==NULL) sikertelen_lefoglalas = true;
    uj->kov = NULL;
    uj->index = index;
    if(sikertelen_lefoglalas){
        felszabadit(uj);
        return NULL;
    }
    return uj;
}

bool mezo_beolvas(char *mezo, char *egesz_sor, int max_meret, int *szumma_hossz, char lezaro_karakter){
    char beolvaso;
    int hossz = 0;
    while(sscanf(&egesz_sor[(*szumma_hossz)++], "%c", &beolvaso)==1 && hossz<max_meret-1 && beolvaso!=lezaro_karakter){
        mezo[hossz++] = beolvaso;
    }
    if(beolvaso!=lezaro_karakter){
        return false;
    }
    mezo[hossz]='\0';
    return true;
}

void rekordba_beolvas(Rekord *uj, char *szoveg, int *index, Meretek maxmeret){
    int szumma_hossz=0;
    uj->index = -1;
    if(uj==NULL) return;
    if(!mezo_beolvas(uj->nev, szoveg, maxmeret.n, &szumma_hossz, '\t')) return;
    if(!mezo_beolvas(uj->telefonszam, szoveg, maxmeret.t, &szumma_hossz, '\t')) return;
    if(!mezo_beolvas(uj->cim, szoveg, maxmeret.c, &szumma_hossz, '\t')) return;
    if(!mezo_beolvas(uj->foglalkozas, szoveg, maxmeret.f, &szumma_hossz, '\n')) return;
    uj->index = ++(*index);
}

int fajl_olvasas(char *ut, Meretek *maxmeret, Rekord *tomb){
    FILE *fp;
    int i=0;
    fp = fopen(ut, "r");
    if(fp==NULL){
        return 1;
    }
    bool hiba = false;
    Rekord *iter = tomb;
    int max = maxmeret->n + maxmeret->t + maxmeret->c + maxmeret->f + 4;
    char temp[max];
    while(fgets(temp, max, fp)!=NULL){
        if(!strchr(temp, '\n')){
            hiba = true;
            char szemet;
            while(fscanf(fp, "%c", &szemet)==1 && szemet!='\n');
        } else{
            if(iter->kov==NULL){
                iter->kov = teljesrekord_lefoglal(i, *maxmeret);
                if(iter->kov==NULL){
                    return -1;
                }
                iter->kov->elozo = iter;
            }
            rekordba_beolvas(iter->kov, temp, &i, *maxmeret);
            if(iter->kov->index!=-1){
                iter=iter->kov;
            }else{
                hiba = true;
            }
        }
    }
    felszabadit(iter->kov);
    iter->kov = NULL;

    maxmeret->rekordszam=i;
    fclose(fp);
    return hiba ? 2 : 0;
}

bool fajl_mentes(char *ut, Meretek maxmeret, Rekord *tomb){
    FILE *fp;
    fp = fopen(ut, "w");
    if(fp==NULL){
        return false;
    }
    Rekord *iter;
    for(iter=tomb->kov;iter!=NULL;iter=iter->kov){
        fprintf(fp, "%s\t", iter->nev);
        fprintf(fp, "%s\t", iter->telefonszam);
        fprintf(fp, "%s\t", iter->cim);
        fprintf(fp, "%s\n", iter->foglalkozas);
    }
    fclose(fp);
    return true;
}

int vcard_mentes(char *ut, Rekord kivalasztott, Meretek maxmeret){
    char *vezetek_nev = (char*) malloc(maxmeret.n*sizeof(char));
    if(vezetek_nev==NULL){
        return 2;
    }
    char *kereszt_nev = (char*) malloc(maxmeret.n*sizeof(char));
    if(kereszt_nev==NULL){
        free(vezetek_nev);
        return 2;
    }
    char *masodik_nevek = (char*) malloc(maxmeret.n*sizeof(char));
    if(masodik_nevek==NULL){
        free(vezetek_nev);
        free(kereszt_nev);
        return 2;
    }

    FILE *fp;
    fp = fopen(ut, "w");
    if(fp==NULL){
        return 1;
    }
    fprintf(fp, "BEGIN:VCARD\nVERSION:2.1\n");

    int hany_nev=0;
    hany_nev = sscanf(kivalasztott.nev, "%s %s %[^\n]\n", vezetek_nev, kereszt_nev, masodik_nevek);
    switch(hany_nev){
        case 3:
            fprintf(fp, "N:%s;%s;%s;;\n", vezetek_nev, kereszt_nev, masodik_nevek);
            break;
        case 2:
            fprintf(fp, "N:%s;%s;;;\n", vezetek_nev, kereszt_nev);
            break;
        case 1:
            fprintf(fp, "N:%s;;;;\n", vezetek_nev);
            break;
        default:
            fprintf(fp, "N:;;;;\n");
            break;
    }
    fprintf(fp, "TEL:%s\n", kivalasztott.telefonszam);
    fprintf(fp, "LABEL:%s\n", kivalasztott.cim);
    fprintf(fp, "ROLE:%s\n", kivalasztott.foglalkozas);
    fprintf(fp, "END:VCARD");
    free(vezetek_nev);
    free(kereszt_nev);
    free(masodik_nevek);
    fclose(fp);
    return 0;
}

int vcardolvasas_formatumellenorzes(FILE *fp){
    if(fp==NULL){
        return 1;
    }
    char vcard_header[13];
    fgets(vcard_header, 13, fp);
    vcard_header[12] = '\0';
    if(strcmp(vcard_header, "BEGIN:VCARD\n")!=0){
        return 2;
    }
    fgets(vcard_header, 13, fp);
    if(strcmp(vcard_header, "VERSION:2.1\n")!=0){
        return 2;
    }
    return 0;
}

void ures_adatok(Rekord *uj){
    strcpy(uj->nev, "");
    strcpy(uj->telefonszam, "");
    strcpy(uj->cim, "");
    strcpy(uj->foglalkozas, "");
}

int vcard_nev(char *vcard_sor, char *vcard_vege_char, Rekord *uj, Meretek maxmeret){
    for(char *iter=vcard_vege_char-1;*iter==';';iter--){
        *iter = '\0';
    }
    char *nev_masolat = (char*) malloc((strlen(vcard_sor)+1)*sizeof(char));
    if(nev_masolat == NULL){
        return 3;
    }
    int hossz=0;
    for(int i=0;vcard_sor[i+2]!='\0';i++){
        if(vcard_sor[i+2]==';'){
            if(vcard_sor[i+1]!=';' && vcard_sor[i+1]!=' '){
                nev_masolat[hossz++] = ' ';
            }
        }else{
            nev_masolat[hossz++] = vcard_sor[i+2];
        }
    }
    nev_masolat[hossz] = '\0';
    if(strlen(nev_masolat)>maxmeret.n-1){
        free(nev_masolat);
        return 4;
    }
    strcpy(uj->nev, nev_masolat);
    free(nev_masolat);
    return 0;
}

int vcard_mezok(char *vcard_sor, char *tipus, Rekord *uj, bool *vcardvege, Meretek maxmeret){
    if(strcmp(tipus, "TEL")==0){
        if(strlen(vcard_sor)>maxmeret.t-1 + 4){
            return 4;
        }
        strcpy(uj->telefonszam, vcard_sor+4);
    }
    else if(strcmp(tipus, "LABEL")==0){
        if(strlen(vcard_sor)>maxmeret.c-1 + 6){
            return 4;
        }
        strcpy(uj->cim, vcard_sor+6);
    }
    else if(strcmp(tipus, "ROLE")==0){
        if(strlen(vcard_sor)>maxmeret.f-1 + 5){
            return 4;
        }
        strcpy(uj->foglalkozas, vcard_sor+5);
    }
    else if(strcmp(tipus, "END")==0){
        if(strcmp(vcard_sor, "END:VCARD")!=0){
            return 2;
        }
        *vcardvege=true;
    }
    return 0;
}

int vcard_adatok_beolvasasa_ciklus(FILE *fp, char *vcard_sor, int max_hossz, Rekord *uj, Meretek maxmeret){
    bool vcardvege=false;
    char tipus[30];
    while(!vcardvege){
        char *ures = fgets(vcard_sor, max_hossz, fp);
        if(ures==NULL){
            fclose(fp); felszabadit(uj); free(vcard_sor);
            return 2;
        }
        char *vcard_vege_char = strchr(vcard_sor, '\n');
        if(vcard_vege_char==NULL){
            if(!(sscanf(vcard_sor, "%[^:]:", tipus)==1 && strcmp(tipus, "END")==0)){
                fclose(fp); felszabadit(uj); free(vcard_sor);
                return 4;
            }
        }else{
            *vcard_vege_char='\0';
        }
        if(sscanf(vcard_sor, "%[^:]:", tipus)!=1)
            return 2;

        if(strcmp(tipus, "N")==0){
            int hiba = vcard_nev(vcard_sor, vcard_vege_char, uj, maxmeret);
            if(hiba!=0){
                fclose(fp); felszabadit(uj); free(vcard_sor);
                return hiba;
            }
        }
        else{
            int hiba = vcard_mezok(vcard_sor, tipus, uj, &vcardvege, maxmeret);
            if(hiba!=0){
                fclose(fp); felszabadit(uj); free(vcard_sor);
                return hiba;
            }
        }
    }
    return 0;
}

int vcard_olvasas(char *ut, Meretek *maxmeret, Rekord *tomb){
    FILE *fp;
    fp = fopen(ut, "r");
    int formatum_ellenorzes = vcardolvasas_formatumellenorzes(fp);
    if(formatum_ellenorzes!=0){
        fclose(fp);
        return formatum_ellenorzes;
    }

    int max_hossz = maxmeret->n + maxmeret->t + maxmeret->c + maxmeret->f;
    char *vcard_sor = (char*) malloc(max_hossz*sizeof(char));
    if(vcard_sor==NULL){
        fclose(fp);
        return 3;
    }
    Rekord *uj = teljesrekord_lefoglal(maxmeret->rekordszam+1, *maxmeret);
    if(uj==NULL){
        fclose(fp); free(vcard_sor);
        return 3;
    }
    ures_adatok(uj);
    int hiba = vcard_adatok_beolvasasa_ciklus(fp, vcard_sor, max_hossz, uj, *maxmeret);
    if(hiba!=0){
        return hiba;
    }
    ujrekord_hozzafuzese(uj, maxmeret, tomb);
    free(vcard_sor);
    fclose(fp);
    return 0;
}
