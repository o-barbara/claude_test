#ifndef FUGGVENYEK_H_INCLUDED
#define FUGGVENYEK_H_INCLUDED

#include "struktura.h"
#include <stdbool.h>
#include <stdio.h>

void konyv();
char char_scanf();
int int_scanf();
char *mezo_beolvas_lefoglal(char, Meretek);
void szerkesztes(char, Rekord*, Meretek, Rekord*);
bool kereses(char, char*, Rekord*);
bool nevjegy_lista(Rekord*);
Rekord* ujrekord_lefoglalasa(Meretek*, Rekord*);
void rekordkiir(Rekord);
void felszabadit(Rekord*);
void torles(Rekord*, Meretek*, Rekord*);
Rekord *egyezes_kereses(Rekord*, Rekord**);
void ujrekord_hozzafuzese(Rekord*, Meretek*, Rekord*);
void fajlolvasas_hibakezeles(int);
void vcardolvasas_hibakezeles(int);
void regi_nevjegy_felulirasa(Rekord*, Rekord*);


#endif // BEOLVASAS_H_INCLUDED
