#ifdef _WIN32
    #include <windows.h>
#endif

#include <stdio.h>
#include <stdbool.h>
#include <string.h>

#include "debugmalloc.h"
#include "fuggvenyek.h"
#include "struktura.h"

int csillagtalalat(char*);
int wildcard(char*, char*);
void kereses_mezonkent(char, int*, char*, Rekord*);
char *ujrekord_beolvas(char, Meretek);
void mezok_felszabaditasa(Rekord*);

void konyv(){
    printf("           ______ ______\n");
    printf("         _/      Y      \\_ \n");
    printf("        // ~~ ~~ | ~~ ~  \\\\ \n");
    printf("       // ~ ~ ~~ | ~~~ ~~ \\\\ \n");
    printf("      //________.|.________\\\\ \n");
    printf("     `----------`-'----------'\n");
}

char char_scanf(){ //pipa
    char c;
    char szemet;
    bool elso=true;
    int db=0;
    while(scanf("%c", &szemet)==1 && szemet!='\n'){
        if(elso){
            c=szemet;
            elso=false;
        }
        db++;
    }
    if(db==1)
        return toupper(c);
    return 'W';
}

int int_scanf(){ //pipa
    char sor[40];
    int n;
    char c;
    fgets(sor, 40, stdin);
    if(strchr(sor, '\n')==NULL){
        char szemet;
        while(scanf("%c", &szemet)==1 && szemet!='\n');
        return -1;
    }
    if(sscanf(sor, "%d%c", &n, &c)!=2){
        return -1;
    }
    if(c!='\n'){
        return -1;
    }
    return n;
}

char *mezo_beolvas_lefoglal(char tipus, Meretek maxmeret){ //pipa
    int meret;
    switch(tipus){
        case 'N': meret = maxmeret.n; break;
        case 'T': meret = maxmeret.t; break;
        case 'C': meret = maxmeret.c; break;
        case 'F': meret = maxmeret.f; break;
    }
    char *lefoglalt_memoria;
    int hossz=0;
    char beolvaso;
    lefoglalt_memoria = (char*) malloc(meret*sizeof(char));
    if(lefoglalt_memoria==NULL) return NULL;
    while(scanf("%c", &beolvaso)==1 && hossz<meret-1 && beolvaso!='\n'){
        lefoglalt_memoria[hossz++]=beolvaso;
    }
    if(beolvaso!='\n'){
        char szemet;
        while(scanf("%c", &szemet)==1 && szemet!='\n');
        return NULL;
    } else {
        lefoglalt_memoria[hossz]='\0';
        return lefoglalt_memoria;
    }
}

void szerkesztes(char bemenet, Rekord *kivalasztott, Meretek maxmeret, Rekord *tomb){
    char *temp = mezo_beolvas_lefoglal(bemenet, maxmeret);
    while(temp==NULL){
        printf("A bemenet túl hosszú/Nem sikerült memóriát lefoglalni! Írd be újra!\n");
        temp = mezo_beolvas_lefoglal(bemenet, maxmeret);
    }
    switch(bemenet){
        case 'N': strcpy(kivalasztott->nev, temp); break;
        case 'T': strcpy(kivalasztott->telefonszam, temp); break;
        case 'C': strcpy(kivalasztott->cim, temp); break;
        case 'F': strcpy(kivalasztott->foglalkozas, temp); break;
    }
    free(temp);
}

int csillagtalalat(char *szoveg){ //pipa
    for(int i=0;szoveg[i]!='\0';i++){
        if(szoveg[i]=='*')
            return i;
    }
    return -1;
}

int wildcard(char *nev, char *osszehasonlitando){ //pipa
    if(strcmp(nev, osszehasonlitando)==0){
        return true;
    }
    int csillaghely = csillagtalalat(osszehasonlitando);
    int osszehasonlitando_meret = strlen(osszehasonlitando);
    int nevmeret = strlen(nev);

    if(csillaghely>0 && csillaghely < osszehasonlitando_meret-1){
        char *elso_resz = (char*) malloc((osszehasonlitando_meret+1)*sizeof(char));
        if(elso_resz==NULL) return -1;
        elso_resz = strcpy(elso_resz, osszehasonlitando);
        elso_resz[csillaghely]='\0';
        char *masodik_resz = &elso_resz[csillaghely+1];
        if(strstr(nev, elso_resz)==nev && strstr(nev, masodik_resz)== (&nev[nevmeret-(osszehasonlitando_meret-csillaghely-1)])){
            free(elso_resz);
            return 1;
        }
        free(elso_resz);
        return false;
    }
    if(csillaghely==0){
        char *elso_resz = &osszehasonlitando[1];
        if(strstr(nev, elso_resz)==&nev[nevmeret-osszehasonlitando_meret+1]){
            return 1;
        }
        return false;
    }
    if(csillaghely==osszehasonlitando_meret-1){
        char *elso_resz = (char*) malloc((osszehasonlitando_meret+1)*sizeof(char));
        if(elso_resz==NULL) return -1;
        elso_resz = strcpy(elso_resz, osszehasonlitando);
        elso_resz[csillaghely]='\0';
        if(strstr(nev, elso_resz)==nev){
            free(elso_resz);
            return 1;
        }

        free(elso_resz);
        return 0;
    }
    return 0;
}

void kereses_mezonkent(char tipus, int *db, char *keresett, Rekord *tomb){ //pipa
    Rekord *iter;
    for(iter=tomb->kov;iter!=NULL;iter=iter->kov){
        switch(tipus){
            case 'T':
                 if(strcmp(iter->telefonszam, keresett)==0){
                    rekordkiir(*iter);
                    (*db)++;
                }
                break;
            case 'C':
                if(strcmp(iter->cim, keresett)==0){
                    rekordkiir(*iter);
                    (*db)++;
                }
                break;
            case 'F':
                if(strcmp(iter->foglalkozas, keresett)==0){
                    rekordkiir(*iter);
                    (*db)++;
                }
                break;
        }
    }
}

bool kereses(char tipus, char *keresett, Rekord *tomb){//pipa
    printf("Keresés eredménye: \n");
    int db=0;

    if(tipus=='N'){
        Rekord *iter;
        for(iter=tomb->kov;iter!=NULL;iter=iter->kov){
            int egyezes = wildcard(iter->nev, keresett);
            if(egyezes==1){
                rekordkiir(*iter);
                db++;
            }
            if(egyezes==-1) return false;
        }
    }else{
        kereses_mezonkent(tipus, &db, keresett, tomb);
    }

    printf("Találatok száma: %d\n", db);
    return true;
}

bool nevjegy_lista(Rekord *tomb){ //pipa
    if(tomb->kov==NULL) return true;
    Rekord *iter;
    for(iter=tomb->kov;iter!=NULL;iter=iter->kov){
        rekordkiir(*iter);
    }
    return false;
}

char *ujrekord_beolvas(char tipus, Meretek maxmeret){ //pipa
    char *uj_mezo;
    char tipus_teljes_nev[20];
    switch(tipus){
        case 'N':
            strcpy(tipus_teljes_nev, "név");
            break;
        case 'T':
            strcpy(tipus_teljes_nev, "telefonszám");
            break;
        case 'C':
            strcpy(tipus_teljes_nev, "cím");
            break;
        case 'F':
            strcpy(tipus_teljes_nev, "foglalkozás");
    }
    printf("Add meg a %s mezőt! ", tipus_teljes_nev); //kukoj
    uj_mezo = mezo_beolvas_lefoglal(tipus, maxmeret);
    while(uj_mezo==NULL){
        printf("A bemenet túl hosszú/Nem sikerült memóriát lefoglalni! Írd be újra!\n");
        uj_mezo = mezo_beolvas_lefoglal(tipus, maxmeret);
    }
    return uj_mezo;
}

Rekord *ujrekord_lefoglalasa(Meretek *maxmeret, Rekord *tomb){
    Rekord *uj = (Rekord*) malloc(sizeof(Rekord));
    if(uj==NULL){
        return NULL;
    }
    uj->nev = ujrekord_beolvas('N', *maxmeret);
    uj->telefonszam = ujrekord_beolvas('T', *maxmeret);
    uj->cim = ujrekord_beolvas('C', *maxmeret);
    uj->foglalkozas = ujrekord_beolvas('F', *maxmeret);
    uj->kov = NULL;
    return uj;
}

void ujrekord_hozzafuzese(Rekord *uj, Meretek *maxmeret, Rekord *tomb){ //pipa
    Rekord *iter = tomb;
    while(iter->kov!=NULL){
        iter=iter->kov;
    }
    iter->kov = uj;
    uj->elozo=iter;
    maxmeret->rekordszam++;
    uj->index = maxmeret->rekordszam;
    printf("Sikeres importálás! ");
}

Rekord *egyezes_kereses(Rekord *keresett, Rekord **honnan){ //pipa
    Rekord *iter;
    for(iter=*honnan;iter!=NULL;iter=iter->kov){
        if(strcmp(iter->nev, keresett->nev)==0 || strcmp(iter->telefonszam, keresett->telefonszam)==0){
            *honnan=iter->kov;
            return iter;
        }
    }
    return NULL;
}

void rekordkiir(Rekord nevjegy){ //pipa
    printf("<---%d--->\n", nevjegy.index);
    printf("Név: %s\n", (strlen(nevjegy.nev)==0)? "-" : nevjegy.nev);
    printf("Telefonszám: %s\n", (strlen(nevjegy.telefonszam)==0)? "-" : nevjegy.telefonszam);
    printf("Lakcím: %s\n", (strlen(nevjegy.cim)==0)? "-" : nevjegy.cim);
    printf("Foglalkozás: %s\n\n", (strlen(nevjegy.foglalkozas)==0)? "-" : nevjegy.foglalkozas);
}

void mezok_felszabaditasa(Rekord *nevjegy){ //pipa
    free(nevjegy->nev);
    free(nevjegy->telefonszam);
    free(nevjegy->cim);
    free(nevjegy->foglalkozas);
}

void felszabadit(Rekord *eleje){ //pipa
    Rekord *iter = eleje;
    while(iter!=NULL){
        if(iter->index!=-2){
            mezok_felszabaditasa(iter);
        }
        Rekord *kov = iter->kov;
        free(iter);
        iter=kov;
    }

}

void torles(Rekord *kivalasztott, Meretek *maxmeret, Rekord *tomb){ //pipa
    mezok_felszabaditasa(kivalasztott);
    if(kivalasztott->kov == NULL){
        kivalasztott->elozo->kov = NULL;
    }else{
        Rekord *iter;
        for(iter=kivalasztott->kov;iter!=NULL;iter=iter->kov){
            iter->index--;
        }
        kivalasztott->elozo->kov = kivalasztott->kov;
        kivalasztott->kov->elozo = kivalasztott->elozo;
    }
    free(kivalasztott);
    maxmeret->rekordszam--;
}

void fajlolvasas_hibakezeles(int hiba){ //pipa
    switch(hiba){
        case 0:
            printf("Sikeres importálás! ");
            break;
        case 1:
            printf("Nem lehet megnyitni a fájlt. ");
            break;
        case 2:
            printf("Figyelem! Volt olyan rekord, amit nem lehet beolvasni. ");
            break;
        case -1:
            printf("Nem sikerült importálni. ");
            break;
    }
}

void regi_nevjegy_felulirasa(Rekord *egyezes, Rekord *uj){ //pipa
    strcpy(egyezes->nev, uj->nev);
    strcpy(egyezes->telefonszam, uj->telefonszam);
    strcpy(egyezes->cim, uj->cim);
    strcpy(egyezes->foglalkozas, uj->foglalkozas);
}

void vcardolvasas_hibakezeles(int hiba){
    switch(hiba){
        case 1:
            printf("Nem lehet megnyitni a fájlt. ");
            break;
        case 2:
            printf("A fájlt tartalmának formátuma hibás. ");
            break;
        case 3:
            printf("Nem sikerült importálni. ");
            break;
        case 4:
            printf("A fájlt nem lehet importálni, mivel egyik mezője túl hosszú adatot tartalmaz. ");
            break;
    }
}

