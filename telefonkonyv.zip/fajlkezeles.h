#ifndef FAJLKEZELES_H_INCLUDED
#define FAJLKEZELES_H_INCLUDED

bool fajl_mentes(char*, Meretek, Rekord*);
int fajl_olvasas(char*, Meretek*, Rekord*);
int vcard_mentes(char*, Rekord, Meretek);
int vcard_olvasas(char*, Meretek*, Rekord*);
void fajl_ut_beolvas(char*, char*);
#endif // FAJLKEZELES_H_INCLUDED
