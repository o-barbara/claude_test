#ifndef STRUKTURA_H_INCLUDED
#define STRUKTURA_H_INCLUDED

#include <stdio.h>

typedef struct Rekord{
    int index;
    char *nev;
    char *telefonszam;
    char *cim;
    char *foglalkozas;
    struct Rekord *kov;
    struct Rekord *elozo;
} Rekord;

typedef struct Meretek{
    int n, t, c, f;
    int rekordszam;
} Meretek;

#endif // STRUKTURA_H_INCLUDED
