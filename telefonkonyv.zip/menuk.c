#ifdef _WIN32
    #include <windows.h>
#endif

#include <stdio.h>
#include <string.h>

#include "debugmalloc.h"
#include "struktura.h"
#include "menuk.h"
#include "fuggvenyek.h"
#include "fajlkezeles.h"

void kereses_kivalasztas_menu(Meretek*, Rekord*);
void kereses_elvegzese_menu(char, Meretek*, Rekord*);
void kivalasztas_menu(Meretek*, Rekord*);
void kivalasztott_felhasznalasa_menu(Rekord*, Meretek*, Rekord*);
void szerkesztes_menu(Rekord*, Meretek, Rekord*);
void nevjegy_menu(Meretek*, Rekord*);
void ujrekord_menu(Meretek*, Rekord*);
void uj_rekord_manualis(Meretek*, Rekord*);
void torles_menu(Rekord*, Meretek*, Rekord*, bool*);
void fajl_mentes_menu(Meretek, Rekord*);
void fajl_olvasas_menu(Meretek*, Rekord*);
void egyezes_menu(Rekord**, Rekord*, Rekord*);
void vcard_mentes_menu(Rekord, Meretek);
void vcard_olvasas_menu(Meretek*, Rekord*);

void fomenu(Meretek *maxmeret, Rekord *tomb, bool *vege){
    printf("\n<----------TELEFONKÖNYV---------->\n");
    konyv();
    printf("Jelenlegi rekordok száma: %d\n", maxmeret->rekordszam);
    printf("Írd be a megfelelő betűt az opció kiválasztásához!\n");
    printf("(K)  * Keresés\n(U)  * Új névjegy hozzáadása\n(S)  * Mentés fájlba\n(L)  * Betöltés fájlból\n(N)  * Névjegyek kilistázása\n(X)  * Bezárás\n");
    char bemenet;
    bool invalid;
    do{
        bemenet=char_scanf();
        invalid = false;
        switch(bemenet){
            case 'K': kereses_kivalasztas_menu(maxmeret, tomb); return;
            case 'U': ujrekord_menu(maxmeret, tomb); return;
            case 'S': fajl_mentes_menu(*maxmeret, tomb); return;
            case 'L': fajl_olvasas_menu(maxmeret, tomb); return;
            case 'N': nevjegy_menu(maxmeret, tomb); return;
            case 'X': *vege=true; return;
            default:
                invalid=true;
                printf("???\n");
                break;
        }
    } while(invalid);
}

void kereses_kivalasztas_menu(Meretek *maxmeret, Rekord *tomb){
    if(tomb->kov==NULL){
        printf("Nincs rekord a telefonkönyvben! Visszatérés a főmenübe.\n\n");
        return;
    }
    printf("\nMi alapján szeretnél keresni?\n");
    printf("(N)  * Név\n(T)  * Telefonszám\n(F)  * Foglalkozás\n(C)  * Cím\n(M)  * Főmenü\n");
    char bemenet;
    bool invalid;
    do{
        bemenet = char_scanf();
        invalid = false;
        if(bemenet != 'N' && bemenet != 'T' && bemenet != 'C' && bemenet != 'F'){
            if(bemenet=='M'){
                return;
            }
            else{
                printf("???\n");
                invalid = true;
            }
        }else{
            kereses_elvegzese_menu(bemenet, maxmeret, tomb);
        }
    } while(invalid);
}

void kereses_elvegzese_menu(char tipus, Meretek *maxmeret, Rekord *tomb){
    printf("\nÍrd be a keresésed!\n");
    char *keresett = mezo_beolvas_lefoglal(tipus, *maxmeret);
    while(keresett==NULL){
        printf("A keresés túl hosszú/Nem sikerült memóriát lefoglalni! Írd be újra!\n");
        keresett = mezo_beolvas_lefoglal(tipus, *maxmeret);
    }
    bool hiba = kereses(tipus, keresett, tomb);
    if(!hiba){
        printf("Nem sikerült keresni. Visszatérés a főmenübe.\n\n");
        return;
    }
    free(keresett);
    printf("\nMit szeretnél csinálni?\n");
    printf("(K)  * Kiválasztás\n(M)  * Főmenü\n");
    char bemenet;
    bool invalid;
    do{
        bemenet = char_scanf();
        invalid = false;
        switch(bemenet){
            case 'M': return;
            case 'K': kivalasztas_menu(maxmeret, tomb); return;
            default: invalid = true; printf("???\n"); break;
        }

    }while(invalid);
}

void kivalasztas_menu(Meretek *maxmeret, Rekord *tomb){
    printf("\nÍrd be a kiválasztott rekord számát (indexét)!\n");
    int szam = int_scanf();
    while(szam > maxmeret->rekordszam || szam<=0){
        printf("Nincs ilyen rekord. Írd be újra!\n");
        szam = int_scanf();
    }
    printf("\nA választott rekordod:\n");
    Rekord *iter=tomb;
    Rekord *kivalasztott=NULL;
    while(iter!=NULL && kivalasztott==NULL){
        if(iter->index==szam){
            kivalasztott=iter;
        }
        iter=iter->kov;
    }
    rekordkiir(*kivalasztott);
    kivalasztott_felhasznalasa_menu(kivalasztott, maxmeret, tomb);
}

void kivalasztott_felhasznalasa_menu(Rekord *kivalasztott, Meretek *maxmeret, Rekord *tomb){
    bool vege = false;
    while(!vege){
        printf("\nMit szeretnél vele csinálni?\n");
        printf("(D)  * Törles\n(E)  * Szerkesztés\n(C)  * vCard formátumba exportálás\n(M)  * Főmenü\n");
        char bemenet;
        bool invalid;
        do{
            bemenet = char_scanf();
            invalid = false;
            switch(bemenet){
                case 'D':
                    torles_menu(kivalasztott, maxmeret, tomb, &vege);
                    break;
                case 'E': szerkesztes_menu(kivalasztott, *maxmeret, tomb); return; break;
                case 'C': vcard_mentes_menu(*kivalasztott, *maxmeret); return; break;
                case 'M': return; break;
                default: printf("???\n"); invalid = true; break;
            }
        } while(invalid);
    }
}

void szerkesztes_menu(Rekord *kivalasztott, Meretek maxmeret, Rekord *tomb){
    printf("\nMit szeretnél szerkeszteni?\n");
    printf("(N)  * Név\n(T)  * Telefonszám\n(C)  * Cím\n(F)  * Foglalkozás\n");
    char bemenet;
    bool invalid;
    do{
        bemenet = char_scanf();
        invalid = false;
        if(bemenet=='N' || bemenet=='T' || bemenet=='C' || bemenet=='F'){
            printf("\nÍrd be az új adatot!\n");
            szerkesztes(bemenet, kivalasztott, maxmeret, tomb);
        }else{
            printf("???\n");
            invalid = true;
        }
    }while(invalid);
    printf("A szerkestés sikeres! Visszatérés a főmenübe.\n\n");
}

void nevjegy_menu(Meretek *maxmeret, Rekord *tomb){
    printf("\nNévjegyek száma: %d\n", maxmeret->rekordszam);
    bool ures = nevjegy_lista(tomb);
    if(ures){
        printf("Nincs rekord a telefonkönyvben! Visszatérés a főmenübe.\n\n");
        return;
    }
    printf("\nMit szeretnél csinálni?\n");
    printf("(K)  * Kiválasztás\n(M)  * Főmenü\n");
    char bemenet;
    bool invalid;
    do{
        bemenet = char_scanf();
        invalid = false;
        switch(bemenet){
            case 'M': return; break;
            case 'K': kivalasztas_menu(maxmeret, tomb); return; break;
            default: invalid = true; printf("???\n"); break;
        }
    }while(invalid);
}

void ujrekord_menu(Meretek *maxmeret, Rekord *tomb){
    printf("\nHogyan szeretnél új névjegyjet hozzáadni?\n");
    printf("(C)  * Importálás vCard formátumból\n(I)  * Importálás manuálisan\n(M)  * Főmenü\n");
    char bemenet;
    bool invalid = false;
    do{
        bemenet = char_scanf();
        invalid = false;
        switch(bemenet){
            case 'C':
                vcard_olvasas_menu(maxmeret, tomb);
                return;
            case 'I':
                uj_rekord_manualis(maxmeret, tomb);
                printf("Visszatérés a főmenübe.\n\n");
                return;
            case 'M': return;
            default:
                invalid = true;
                printf("???\n");
                break;
        }
    } while(invalid);
}

void uj_rekord_manualis(Meretek *maxmeret, Rekord *tomb){
    Rekord *uj = ujrekord_lefoglalasa(maxmeret, tomb);
    if(uj==NULL){
        printf("Nem sikerült importálni. ");
    }else{
        Rekord *iter=tomb->kov;
        Rekord *egyezes = egyezes_kereses(uj, &iter);
        while(egyezes!=NULL && uj!=NULL){
            egyezes_menu(&uj, egyezes, tomb);
            if(uj!=NULL){
                egyezes = egyezes_kereses(uj, &iter);
            }
        }
        if(uj!=NULL){
            ujrekord_hozzafuzese(uj, maxmeret, tomb);
        }
    }
}

void torles_menu(Rekord *kivalasztott, Meretek *maxmeret, Rekord *tomb, bool *vege){
    printf("\nBiztos törölni akarod?\n");
    printf("(I)  * Igen\n(N)  * Nem\n");
    char bemenet;
    bool invalid;
    do{
        bemenet = char_scanf();
        invalid=false;
        switch(bemenet){
            case 'I':
                *vege=true;
                torles(kivalasztott, maxmeret, tomb);
                printf("Sikeres törlés. Visszatérés a főmenübe.\n\n");
                return;
            case 'N': return;
            default: printf("???\n"); invalid = true; break;
        }
    } while(invalid);
}

void fajl_mentes_menu(Meretek maxmeret, Rekord *tomb){
    if(tomb->kov==NULL){
        printf("Nincs rekord a telefonkönyvben! Visszatérés a főmenübe.\n\n");
        return;
    }
    printf("\nÍrd be a fájl elérési útvonalát!\n");
    char ut[200];
    fajl_ut_beolvas(ut, ".txt\n");
    bool sikeres = fajl_mentes(ut, maxmeret, tomb);
    printf("%s", (sikeres) ? "Sikeres exportálás! " : "Nem lehet megnyitni a fájlt. ");
    printf("Visszatérés a főmenübe.\n\n");
}

void fajl_olvasas_menu(Meretek *maxmeret, Rekord *tomb){
    printf("\nÍrd be a fájl elérési útvonalát!\n");
    char ut[200];
    fajl_ut_beolvas(ut, ".txt\n");
    printf("Biztosan importálni akarsz? Az eddigi névjegyeid elvesznek.\n");
    printf("(I)  * Igen\n(N)  * Nem\n");
    char bemenet;
    bool invalid;
    int hiba;
    do{
        bemenet = char_scanf();
        invalid = false;
        switch(bemenet){
            case 'I':
                hiba = fajl_olvasas(ut, maxmeret, tomb);
                break;
            case 'N':
                return;
                break;
            default:
                printf("???\n");
                invalid = true;
                break;
        }
    }while(invalid);
    fajlolvasas_hibakezeles(hiba);
    printf("Visszatérés a főmenübe.\n\n");
}

void egyezes_menu(Rekord **uj, Rekord *egyezes, Rekord *tomb){
    printf("\nAz importálandó rekord neve/telefonszáma már létezik. A rekord:\n");
    rekordkiir(*egyezes);
    printf("Mit szeretnél csinálni?\n");
    printf("(F)  * Régi névjegy felülírása\n(E)  * Új névjegy elvetése\n(I)  * Új névjegy importálása a régitől függetlenül\n");
    char bemenet;
    bool invalid;
    do{
        bemenet = char_scanf();
        invalid = false;
        switch(bemenet){
            case 'F':
                regi_nevjegy_felulirasa(egyezes, *uj);
            case 'E':
                felszabadit(*uj);
                *uj = NULL;
                return;
            case 'I':
                return;
            default: printf("???\n"); invalid = true;
        }
    }while(invalid);
}

void vcard_mentes_menu(Rekord kivalasztott, Meretek maxmeret){
    printf("\nÍrd be a fájl elérési útvonalát!\n");
    char ut[200];
    fajl_ut_beolvas(ut, ".vcf\n");
    int hiba = vcard_mentes(ut, kivalasztott, maxmeret);
    switch(hiba){
        case 0:
            printf("Sikeres exportálás! ");
            break;
        case 1:
            printf("Nem lehet megnyitni a fájlt. ");
            break;
        case 2:
            printf("Nem sikerült importálni. ");
            break;
    }
    printf("Visszatérés a főmenübe.\n\n");
}

void vcard_olvasas_menu(Meretek *maxmeret, Rekord *tomb){
    printf("\nÍrd be a fájl elérési útvonalát!\n");
    char ut[200];
    fajl_ut_beolvas(ut, ".vcf\n");
    int hiba = vcard_olvasas(ut, maxmeret, tomb);
    vcardolvasas_hibakezeles(hiba);
    printf("Visszatérés a főmenübe.\n\n");
}
