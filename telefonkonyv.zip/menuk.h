#ifndef MENUK_H_INCLUDED
#define MENUK_H_INCLUDED

#include <stdio.h>
#include <stdbool.h>
#include "struktura.h"

void fomenu(Meretek*, Rekord*, bool*);

#endif // MENUK_H_INCLUDED
